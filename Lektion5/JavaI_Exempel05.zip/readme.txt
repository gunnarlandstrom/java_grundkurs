Ex05_01 - Person.java
Klassen person (som superklass i arv)

Ex05_02 - Child.java
Första exemplet på arv där Child ärver från Person

Ex05_03 - ChilTest.java
Provar att skapa objekt av både Child- och Person

Ex05_04 - ChildTest1.java
Skapar objekt av Child men lagras i en referens till Person

Ex05_05 - Child1.java
Child utökar (ärver) Person med egna instansvariabler och konstruktorer

Ex05_06 - Employee.java
Skapar ännu en subklass, Employee, som ärver från Person

Ex05_07 - InheritanceTest.java
Provar att skapa olika Child- och Employee-objekt

Ex05_08 - Child2.java
Omdefinierar (överskuggar) ärvda metoder från klassen Person

Ex05_09 - Employee1.java
Omdefinierar ärvda metoder från klassen Person

Ex05_10 - InheritanceTest1.java
Provar att skapa olika Child2- och Employee1-objekt igen