/**
 * Ex05_02 - Child
 *
 * Ett första exempel på att arv. Klassen ärver sina
 * egenskaper från klassen Person. Vi utökar inte
 * klassen med egna instansvariabler och metoder
 * utan visar på att Child nu kommer att ha samma
 * metoder som klassen Person.
 *
 * @author Robert Jonsson
 */
public class Child extends Person {
}