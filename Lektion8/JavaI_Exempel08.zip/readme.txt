Ex08_01 - Person.java (i mappen tmp)
Samma Person-klass som i Ex05_01

Ex08_02 - Child.java (i mappen tmp)
En subklass till Person, samma som i Ex05_08

Ex08_03 - Employee.java (i mappen tmp)
En subklass till Person, samma som i Ex05_09

Ex08_04 - PackageTest.java (i mappen tmp)
Provar att skapa Person-objekt, samma som i Ex_05_10

Ex08_05 - SystemIn.java
Använder enbart System.in för att läsa data från tangentbordet

Ex08_06 - SystemIn2.java
Använder BufferedReader för att läsa data från tangentbordet

Ex08_07 - WriteFile.java
Sparar det användaren skriver till en textfil på användarens dator

Ex08_08 - ReadFile.java
Läser innnehållet i en textfil och skriver ut på skärmen

Ex08_09 - ReadFileScanner.java
Läser innnehållet i en textfil med Scanner och skriver ut på skärmen

Ex08_10 - ReadURL.java
Läser innehållet från en resurs (webbsida) på internet

Ex08_11 - ReadImageFromURL.java
Sparar en bild från internet till användarens dator