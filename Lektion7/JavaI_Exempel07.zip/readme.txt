Ex07_00 - Person.java
Vår Person-klass från tidigare lektioner

Ex07_01 - MyFirstArray.java
Skapar en heltals-array och tilldelar den värden

Ex07_02 - RandomArray.java
Slumpar ett antal heltal till en array

Ex07_03 - PersonArray.java
Ett array av Person-objekt där användaren anger data om personerna

Ex07_04 - Multiplication.java
Skapar och använder en 2D-array

Ex07_05 - PassAndReturn.java
Metoder som tar emot och returnerar arrayer

Ex07_06 - ExpandArray.java
Visar har man kan utöka antalet element i en array

Ex07_07 - SelectionSort.java
Sorterar heltalsarray med selection sort

Ex07_08 - ArraysSort.java
Sorterar heltalsarray med Arrays.sort()

Ex07_09 - SortTime.java
Jämför hur lång tid det tar att sortera 100000 element

Ex07_10 - Person2.java
Person som implementerar Comparable

Ex07_11 - PersonSort.java
Sorterar Personer med klassen Arrays

Ex07_12 - PersonNameComparator
En Comparator för att jämföra personers efter deras namn

Ex07_13 - PersonAgeComparator
En Comparator för att jämföra personer efter deras ålder

Ex07_14 - PersonSortArrayList
Sorterar Personer med klassen Collections och olika Comparator<Person>

Ex07_15 - Util
Exempel på en klass med enbart statiska "bra-och-ha"-metoder som övriga klasser kan använda sig av