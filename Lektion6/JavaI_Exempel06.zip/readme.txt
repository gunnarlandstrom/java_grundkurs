Ex06_01 - StringReverser.java
Använder strängmetoderna length och charAt för att skriva ut en sträng i bakvänd ordning.

Ex06_02 - FileName.java
Använder metoderna lastIndexOf och substring i klassen String.

Ex06_03 - CompareTo.java
Metoden compareTo i String används för att kolla alfabetisk ordning.

Ex06_04 - StringTest.java
Mäter hur (o)effektiv klassen String är för strängaddition.

Ex06_05 - StringBuilderTest.java
Mäter hur effektiv klassen StringBuilder är för strängaddition.

Ex06_06 - Palindrom.java
Använder metoden spliti klassen String för att avgöra om en mening är ett palindrom.

Ex06_07 - ScannerTest.java
Använder klassen Scanner för att läsa från fil.